# Browser test evidence

Tested with Linux Chromium / Playwright, headless WebGL via SwiftShader, using a local HTTP server. This does not establish Windows Chrome/Edge compatibility, native GPU performance, or Unity readiness.

## Passed in a real browser

- WebGL scene and original procedural vehicle/course render; no JavaScript page errors.
- Race menu, three-second countdown, J acceleration: observed 22.2 km/h.
- K braking followed by automatic reverse: observed R and 9.0 km/h after near-standstill direction change.
- Automatic upshift: observed gear 2, 68.7 km/h, approximately 4,672 RPM.
- First gate crossing enables timer and advances expected gate to 2.
- D steering changes steering state and physical yaw (0.7223 to 0.7791 radians).
- C cycles 0 → 1 → 2 → 3 → 0. Cockpit render inspected.
- ESC pauses, clock remains frozen; resume and main menu work.
- All five vehicle selections and five course selections update the game state. All course lengths exceed 1 km.
- Four weather and four tire selections update state.
- Tarmac tire grip data: clear asphalt 1.38; rain asphalt 0.52; snow 0.108. These are data checks, not braking-distance measurements.
- Three.js npm archive SHA-512 verified against npm registry integrity; MIT license included.

## Not yet verified

- Direct file:// execution: blocked by the cloud browser's administrator policy. Local HTML uses classic scripts, no fetch/CDN/module imports, and no remotely loaded assets.
- Windows Chrome or Edge execution, native GPU performance, 60 FPS.
- Complete end-to-end stage finishes, three-lap circuit finishes, persistence after a browser restart.
- Quantitative braking/cornering comparison, precise handbrake/airborne/skid behavior, all car × course × tire × weather combinations.
- Unity import, C# compilation, Unity WheelCollider behavior or Unity WebGL build.

The browser prototype is a separate implementation. It provides a playable test of controls and presentation; it is not a substitute for the Unity validation plan.
